#Cyrus Diaz
# None




import random
#imports random for use in drawing a random amount of cards. Used for the bot(player_2)

def player_1(draw, deck):
    """Function player_1 checks to see if the player has won.

    Parameters:
        draw: number of cards drawn
        deck: number of cards in deck

    Returns:
        If draw = deck, returns deck to be "You win! Game over.". If not, it will subtract draw number from deck.


    """
    if draw == deck:
        return "You win! Game over."
    else:
        deck = deck - draw
    
    return deck
        
    #if statement checks to see if player has won the game


def player_2(draw, deck):
    """Function player_2 checks to see if the bot has won.

    Parameters:
        draw: number of cards drawn
        deck: number of cards in deck

    Returns:
        If draw = deck, returns deck to be "I win! Game over.". If not, it will subtract draw number from deck.


    """
    if draw == deck:
        return "I win! Game over."
    else:
        deck = deck - draw

    return deck

    #if statement checks to see if bot has won the game

def draw_cards_p1(deck):
    """Function draw_cards_p1 returns the value of deck after the player draws a number of cards.

    Parameters:
        deck: number of cards in deck

    Returns:
        the value of deck


    """
        
    print("\nThere are " + str(deck) + " cards left\n")

    flag = False



    while flag == False:
        draw = int(input("How many cards do you pick (1-3): "))
        if draw < 1 or draw > 3 or draw > deck:
            print("\tCannot pick " + str(draw) + " cards")
            flag = False
                    
        else:
            print("\tYou picked " + str(draw) + " cards\n")
            deck = player_1(draw, deck)
            flag = True
    return deck
                    
    #after printing the message telling the user how many cards are left, the user is asked to draw 1-3 cards.
    #a while loop is used to infinitely loop the input until the user draws a legal amount of cards.
    #once a legal number of cards has been picked, it prints how many cards were drawn and calls upon the function 'player_1".
    #the function is assigned to deck to ensure the value of the deck is correct. It then makes the flag 'True' to stop the while loop.

def draw_cards_p2(deck):
    """Function draw_cards_p2 returns the value of deck after the bot draws a number of cards.

    Parameters:
        deck: number of cards in deck

    Returns:
        the value of deck


    """
    print("\nThere are " + str(deck) + " cards left\n")


    if deck <= 3:
        draw = random.randint(1,deck)
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)
    else:
        draw = random.randint(1,3)
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)
        

    return deck

    #after printing the message telling the user how many cards are left, the bot draws 1-3 cards using random.randint
    #it will draw a random amount of cards between 1-3 unless deck is <= 3. it will seek for a value between 1,deck to ensure no errors.
    #once a legal number of cards has been picked, it prints how many cards were drawn and calls upon the function 'player_2".
    #the function is assigned to deck to ensure the value of the deck is correct.

def draw_cards_cheat(deck):
    """Function draw_cards_cheat returns the value of deck after the bot draws a number of cards. This function is used
    only when the player goes second, and ensures the bot always wins.

    Parameters:
        deck: number of cards in deck

    Returns:
        the value of deck


    """
    print("\nThere are " + str(deck) + " cards left\n")


    if deck <= 3:
        draw = deck
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)
    elif deck % 4 == 0:
        draw = random.randint(1,3)
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)
    elif deck % 4 == 1:
        draw = 1
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)
    elif deck % 4 == 2:
        draw = 2
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)
    elif deck % 4 == 3:
        draw = 3
        print("\tI pick " + str(draw) + " cards\n")
        deck = player_2(draw, deck)


    return deck

    #after printing the message telling the user how many cards are left, the the bot draws 1-3 cards depending on how many cards are in the deck.
    #it will draw a random amount of cards between 1-3 by modding the deck by 4. It will draw a random amount of cards between 1-3 if deck%4=0 as a failsafe.
    #if the deck is <= 3, it will draw the rest of the cards in deck.
    #once a legal number of cards has been picked, it prints how many cards were drawn and calls upon the function 'player_2".
    #the function is assigned to deck to ensure the value of the deck is correct.
    #this function ensures that the bot always wins.




############################################################################################################################################################




print("New Game Start")
#greets the user

flag = False

while flag == False:
    choice = input("Do you want to go first (y/n): ")
    if choice != "y" and choice != "n":
        flag = False
    else:
        flag = True

#using a while loop, it asks the user if it wants to go first or not. if the input is not y or n, it will continue through the loop until a legal
#input is used

print("-----------------------------------------\n")
#separates the intro and the game messages

deck = 21
#assigns deck of cards to 21

flag = False

while flag == False:
    if choice == "y":
        deck = draw_cards_p1(deck)
        if deck == "You win! Game over.":
            print(deck)
            flag = True
        else:
            deck = draw_cards_p2(deck)
            if deck == "I win! Game over.":
                print(deck)
                flag = True
            else:
                print("-----------------------------------------")
    elif choice == "n":
        deck = draw_cards_cheat(deck)
        if deck == "I win! Game over.":
            print(deck)
            flag = True
        else:
            deck = draw_cards_p1(deck)
            if deck == "You win! Game over.":
                print(deck)
                flag = True
            else:
                print("-----------------------------------------")
            



#using a while loop, it keeps calling upon the functions until either the player or the bot wins
#if user inputs 'y', it will go through the first statement in the if statement until either player or bot wins
#vice versa if the user inputs 'n' except the player will always lose when going second.
#if the deck value is assigned to "You win! Game over." or "I win! Game over.", it prints it and sets the flag to true to end the game.










